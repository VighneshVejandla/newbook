package com.cts.dto;

import lombok.Data;

@Data
public class UserToPaymentDTO {
    private Long userId;
    //	@NotEmpty
    private String name;
    //	@NotEmpty
//	@Email
    private String email;
    //	@NotEmpty
    private String password;
    private String role;
}
