package com.cts.dto;

import lombok.Data;

@Data
public class PaymentResponseDTO {
    private double totalPrice;
}
