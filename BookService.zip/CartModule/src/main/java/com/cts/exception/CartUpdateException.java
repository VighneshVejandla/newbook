package com.cts.exception;

public class CartUpdateException extends RuntimeException {
    public CartUpdateException(String message) {
        super(message);
    }
}
