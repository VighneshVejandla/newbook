package com.cts.feign;

import com.cts.dto.CartToPaymentDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(url = "http://localhost:8003", value="CARTMODULE")
public interface CartServiceClient {
    @GetMapping("/api/v1/cart/{userId}/total-price")
    ResponseEntity<Double> calculateTotalPrice(@PathVariable Integer userId);

    @DeleteMapping("/api/v1/cart/{userId}/clearcart")
    ResponseEntity<String> clearCart(@PathVariable Integer userId);
}
